Project Plan (Including Design Comps and Design Rationalisation) and other Developed Pages, together with the CSS/JS/PHP files are in the "sub" folder.
The website is uploaded to a SiteGround. Please visit: http://xuyangw.sgedu.site/petitetreats/index.html
Github Repository: https://github.com/wangxuyangjcu/CP5638_Assignment2
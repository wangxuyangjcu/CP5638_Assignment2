<!doctype html>
<html>
<head>
<title>Newsletter Signup</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0" charset="UTF-8">
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
</head>

<body>
<ul class="navbar">
	<li><a class = "li_left-l li_left-s" href = "../index.html">Home</a></li>
	<li><a class = "li_left-l li_left-s" href = "../sub/menu.html">Menu</a></li>
	<li><a class = "li_left-l li_left-s" href = "../sub/weekly_specials.html">Weekly Specials</a></li>
	<li><a class = "li_right-l li_right-s" href = "../sub/about_us.html">About Us</a></li>
</ul>
<div class="navbar_holder">
  <ul class="navbar_holder"><li class="li_left">  </li></ul>
	</div>
<!-- Main content starts here -->
<div class="row">
	<div class="col-2 col-s-1"></div>
	<div class="col-8 col-s-10">
		<div class="article_back-l article_back-s">
			<p class="article_title-l article_title-s">Newsletter Signup</p>
			<br>Thank you for signing up for the Petite Treats Weekly newsletter.<br>
			We have added the following information to our files regarding your interests:
			<p class="table_item-l table_item-s">Name:</p><?php echo $_POST["name"]; ?><br>
			<p class="table_item-l table_item-s">Email: </p><?php echo $_POST["email"]; ?><br>
			<?php $str1 = " ";
						if ((isset($_POST["product1"])) || 
							(isset($_POST["product2"])) || 
							(isset($_POST["product3"])) ||
							(isset($_POST["product4"])) ||
							(isset($_POST["product5"])) ||
							(isset($_POST["product6"])))
							$str1.= "<p class='table_item-l table_item-s'>Product interests:</p>";
						echo $str1;    ?>
				<?php $str = " ";
						if (isset($_POST["product1"]))
							$str.= $_POST["product1"].= "<br>";
						if (isset($_POST["product2"]))
							$str.= $_POST["product2"].= "<br>";
						if (isset($_POST["product3"]))
							$str.= $_POST["product3"].= "<br>";
						if (isset($_POST["product4"]))
							$str.= $_POST["product4"].= "<br>";
						if (isset($_POST["product5"]))
							$str.= $_POST["product5"].= "<br>";
						if (isset($_POST["product6"]))
							$str.= $_POST["product6"];		
						echo $str;    ?>
<p class="table_item-l table_item-s">Birthday: </p>
Day:&nbsp;<?php echo $_POST["birth_day"]; ?>&nbsp;&nbsp; Month:&nbsp;<?php echo $_POST["birth_month"]; ?>
			<p></p>
		<p></p>
		<p></p>
		</div>
		
	</div>
	<div class="col-2 col-s-1"></div>
</div> 


<!-- Footer --> 	
<div class="footer_back-l footer_back-s">
	<ul class="footer_ul">
		<li class="footer_li-l footer_li-s"><b>Contacts</b>: 0455 5555 555</li>
		<li class="footer_li-l footer_li-s"><b>Catering</b>: 0433 3333 333</li>
		<li class="footer_li-l footer_li-s"><b>Address</b>: 123 Prize Lane, Kirwan, QLD</li>
	</ul>
</div>

</body>
</html>

function ok_go() { 
	var a1 = document.getElementById("name").value;
	var a2 = document.getElementById("email").value;
	var a3 = document.getElementById("birth").value;
	var a4 = document.getElementById("agree").value;
	var email_check = document.getElementById("email");
	if (a1 != "" & a2 != "" & a3 != "" & a4 != "") {
		confirm("Are you sure to submit?");}
	else {return false;}
	}


function validateForm() {
  var a1 = document.getElementById("name").value;
  var a2 = document.getElementById("email").value;
  if (check_name(a1) || isEmail(a2) || check_birthday()){ 
		return false; }
	else {return true;}
}

function check_name(a1) {
	if (a1.length < 2) {
    alert("Please enter a user name that has more than one letter.");
    return true;
  }
  else {return false;}
}

function isEmail(a2) {
if (a2.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1)
return false;
else {
alert("Please enter a valid Email address.");
return true;}
}


function check_birthday() {
	var a1 = int(document.getElementById("birth_month").value);
	var a2 = int(document.getElementById("birth_day").value);
	var range = [4,6,9,11];
	var a3 = range.indexof(a1);
	if (a1 == 2 & a2 > 29) {
		alert("Please enter a valid date of birth");
		return true;}
		else {return false;}
	if (a3 > -1 & a2 > 30) {
		alert("Please enter a valid date of birth");
		return true;}
		else {return false;}
}


function check_birthday() {
	var a1 = document.getElementById("birth_month").value;
	var a2 = document.getElementById("birth_day").value;
	<!-- var range = [4,6,9,11]-->
	<!--var a3 = range.indexof(a1)-->
	if (a1 == 2 & a2 > 29) {
		alert("Please enter a valid date of birth");
		return true;}
	if (a1 == 4 || a1 == 6 || a1 == 9 || a1 == 11 & a2 > 30) {
		alert("Please enter a valid date of birth");
		return true;}
else {return false;}	
}

